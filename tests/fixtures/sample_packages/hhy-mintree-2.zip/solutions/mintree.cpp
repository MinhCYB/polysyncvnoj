/**
 *  Created at 08:53, Friday July 29, 2022 
 *  By msct <3
 */ 
#include <bits/stdc++.h>
#define task    "mintree"
#define mp  make_pair
#define ll  long long
#define ul  unsigned long long
#define ii  pair<int, int>
#define F   first
#define S   second
#define pb  push_back
#define sz(x) (int)(x).size()
#define bit(x, n) (((x) >> (n)) & 1)
#define For(i, a, b) for(int (i)=(int)(a);(i)<=(int)(b);++(i))
#define Fod(i, a, b) for(int (i)=(int)(a);(i)>=(int)(b);--(i))
#define fopen freopen (task".inp", "r", stdin); freopen (task".out", "w", stdout)

const int N = 30007;
const int M = 100007;
const int INF = 100000100;
const int base = 131;
const int mod = 100000007;

using namespace std;

struct edge {
    int u, v, w;
};

bool cmp (edge a, edge b) {
    return a.w < b.w;
}

int n, m;
int root[N];
ll res = 0LL;
edge a[M];

int find (int u) {
    return (root[u]) ? root[u] = find(root[u]) : u;
}

void kruskal () {
    sort (a + 1, a + m + 1, cmp);
    memset (root, 0, sizeof root);
    For (i, 1, m) {
        int p = find(a[i].u);
        int q = find(a[i].v);
        if (p != q) {
            root[p] = q;
            res += a[i].w;
        }
    }
}

int main () {
    ios_base::sync_with_stdio(NULL);
    cin.tie(NULL);
    freopen (task ".inp", "r", stdin);
    freopen (task ".out", "w", stdout);
    cin >> n >> m;
    For (i, 1, m) cin >> a[i].u >> a[i].v >> a[i].w;
    kruskal ();
    cout << res;
    return 0;
}