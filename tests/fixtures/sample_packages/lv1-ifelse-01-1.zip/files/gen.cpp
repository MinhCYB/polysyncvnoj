#include "testlib.h"
#include <bits/stdc++.h>
 
using namespace std;
 
mt19937 rng(28052006);
 
long long rd(long long l, long long r) {
    uniform_int_distribution<long long> dist(l, r);
    return dist(rng);
}
 
int main(int argc, char* argv[])
{
    registerGen(argc, argv, 1);
    rng.seed(stoi(argv[1]));

    // sinh n, k
    int a = rd(-100, 100);
    int b = rd(-100, 100);
    cout << a << ' ' << b << '\n';
    
    return 0;
}