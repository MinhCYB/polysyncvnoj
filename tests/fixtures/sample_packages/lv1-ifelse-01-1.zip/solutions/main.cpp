#include <bits/stdc++.h>

using namespace std;

int a, b;

int main()
{
    cin >> a >> b;
    cout << a+b << endl;
    cout << a - b << endl;
    cout << a * b << endl;
    cout << fixed << setprecision(2);
    if (b == 0) {
        cout << "ERROR" << endl;
    }
    else {
        cout << float(a)/float(b) << endl;
    }
    return 0;
}
